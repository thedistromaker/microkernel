
#include "tty.h"

void tty_init() {
    // Placeholder terminal init
}

void tty_puts(const char *str) {
    while (*str) tty_putc(*str++);
}

void tty_putc(char c) {
    // Low-level output placeholder
}
