
#include "exec.h"
#include "tty.h"
#include <stdint.h>

typedef struct {
    unsigned char magic[4];
    uint8_t elf_class;
    uint8_t data;
    uint8_t version;
    uint8_t os_abi;
    uint8_t abi_version;
    unsigned char pad[7];
    uint16_t type;
    uint16_t machine;
    uint32_t version2;
    uint32_t entry;
} ElfHeader;

int exec_elf(const char *path) {
    // Simulated ELF loader
    tty_puts("Executing ELF binary: ");
    tty_puts(path);
    tty_putc('\n');

    // In real mode: load ELF, map into memory, jump to entry
    return 0;
}
