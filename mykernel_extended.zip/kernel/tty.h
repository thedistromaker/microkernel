
#ifndef TTY_H
#define TTY_H

void tty_init();
void tty_puts(const char *str);
void tty_putc(char c);

#endif
