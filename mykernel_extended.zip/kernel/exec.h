
#ifndef EXEC_H
#define EXEC_H

int exec_elf(const char *path);

#endif
