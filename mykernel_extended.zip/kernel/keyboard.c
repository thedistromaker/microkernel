
#include "keyboard.h"
#include "tty.h"

void keyboard_init() {
    // Placeholder keyboard init
    tty_puts("Keyboard initialized\n");
}

char keyboard_read() {
    // Placeholder: return dummy char
    return 'A';
}
