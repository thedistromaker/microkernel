
#include "fs.h"

int fs_read(const char *path, char *buf, int len) {
    // Placeholder: simulate read
    return 0;
}

int fs_read_line(const char *path, char *line, int maxlen, int *offset) {
    // Placeholder for reading lines
    return 0;
}
