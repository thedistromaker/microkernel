
#ifndef FS_H
#define FS_H

int fs_read(const char *path, char *buf, int len);
int fs_read_line(const char *path, char *line, int maxlen, int *offset);

#endif
