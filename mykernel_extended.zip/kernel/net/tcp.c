
#include "tcp.h"
#include "tty.h"

void tcp_init() {
    tty_puts("TCP stack initialized\n");
}

void tcp_send(const char *data) {
    tty_puts("TCP Send: ");
    tty_puts(data);
    tty_putc('\n');
}
