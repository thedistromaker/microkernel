
#ifndef TCP_H
#define TCP_H

void tcp_init();
void tcp_send(const char *data);

#endif
