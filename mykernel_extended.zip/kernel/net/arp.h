
#ifndef ARP_H
#define ARP_H

void arp_init();
void arp_request(const char *ip);

#endif
