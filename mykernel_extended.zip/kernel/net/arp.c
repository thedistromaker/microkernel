
#include "arp.h"
#include "tty.h"

void arp_init() {
    tty_puts("ARP initialized\n");
}

void arp_request(const char *ip) {
    tty_puts("Sending ARP request for IP: ");
    tty_puts(ip);
    tty_putc('\n');
}
