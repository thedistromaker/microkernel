
#ifndef KEYBOARD_H
#define KEYBOARD_H

void keyboard_init();
char keyboard_read();

#endif
