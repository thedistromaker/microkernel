
#include "tty.h"
#include "shell.h"

void kernel_main() {
    tty_init();
    tty_puts("Welcome to MyKernel\n");
    shell_loop();
}
