
#include "shell.h"
#include "tty.h"
#include "fs.h"
#include "exec.h"
#include <string.h>

void cmd_echo(const char *args) {
    tty_puts(args);
    tty_putc('\n');
}

void cmd_run(const char *path) {
    exec_elf(path);
}

void shell_execute(const char *command) {
    char cmd[64], args[192];
    sscanf(command, "%63s %191[\n]", cmd, args);

    if (strcmp(cmd, "echo") == 0) {
        cmd_echo(args);
    } else if (strcmp(cmd, "run") == 0) {
        cmd_run(args);
    } else {
        tty_puts("Unknown command: ");
        tty_puts(cmd);
        tty_putc('\n');
    }
}

void shell_loop() {
    char input[256];
    while (1) {
        tty_puts("mysh> ");
        // Placeholder input, replace with actual input logic later
        strcpy(input, "echo Hello Kernel");
        shell_execute(input);
        break;
    }
}
